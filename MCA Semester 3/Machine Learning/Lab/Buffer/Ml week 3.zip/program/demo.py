a1 = int(input('enter a1 '))
a2 = int(input('enter a2 '))

print('sum = ', a1 + a2)